<?php
header('Content-Type: application/json');
include("../config/db.php");

$data = json_decode(file_get_contents("php://input"), true);

$q = $data['question'];
$options = json_encode($data['options']);
$category = $data['category'] ?? 'fun';

$conn->query("
INSERT INTO questions (question_text, options, is_global, category) 
VALUES ('$q','$options',1,'$category')
");

echo json_encode(["status"=>"created"]);