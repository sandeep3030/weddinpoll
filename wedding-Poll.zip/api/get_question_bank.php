<?php
header('Content-Type: application/json');
include("../config/db.php");

$category = $_GET['category'] ?? '';

if ($category) {
    $res = $conn->query("
        SELECT * FROM questions 
        WHERE is_global=1 AND category='$category'
        ORDER BY id DESC
    ");
} else {
    $res = $conn->query("
        SELECT * FROM questions 
        WHERE is_global=1 
        ORDER BY id DESC
    ");
}

$data = [];
while($row = $res->fetch_assoc()){
    $data[] = $row;
}

echo json_encode($data);