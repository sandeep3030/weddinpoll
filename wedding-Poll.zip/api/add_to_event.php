<?php
include("../config/db.php");

$event_id = $_POST['event_id'];
$question_id = $_POST['question_id'];

// 🔍 CHECK EXISTING
$check = $conn->query("
SELECT id FROM event_questions 
WHERE event_id=$event_id AND question_id=$question_id
");

if($check->num_rows > 0){
    echo json_encode(["status"=>"exists"]);
    exit;
}

// get next order
$order = $conn->query("
SELECT IFNULL(MAX(question_order),0)+1 as next_order 
FROM event_questions 
WHERE event_id=$event_id
")->fetch_assoc()['next_order'];

// insert
$conn->query("
INSERT INTO event_questions (event_id, question_id, question_order)
VALUES ($event_id, $question_id, $order)
");

echo json_encode(["status"=>"added"]);

