<?php
header('Content-Type: application/json');
include("../config/db.php");

$code = $_POST['code'];
$mode = $_POST['mode']; // 1 or 0

$conn->query("
UPDATE events 
SET is_random=$mode 
WHERE unique_code='$code'
");

echo json_encode(["status"=>"updated"]);