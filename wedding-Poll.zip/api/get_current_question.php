<?php
header('Content-Type: application/json');
include("../config/db.php");

$code = $_GET['code'];

$q = "
SELECT q.*, 
       e.question_start_time, 
       e.question_duration,
       e.reveal_state
FROM events e
JOIN questions q ON q.id = e.current_question_id
WHERE e.unique_code='$code'
";

$res = $conn->query($q);

echo json_encode($res->fetch_assoc());