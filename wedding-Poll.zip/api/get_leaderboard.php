<?php
header('Content-Type: application/json');
include("../config/db.php");

$code = $_GET['code'];

$event = $conn->query("
SELECT id FROM events WHERE unique_code='$code'
")->fetch_assoc();

$event_id = $event['id'];

// total votes per option (across all questions)
$res = $conn->query("
SELECT option_text, COUNT(*) as total
FROM votes
WHERE event_id=$event_id
GROUP BY option_text
ORDER BY total DESC
");

$data = [];

while($row = $res->fetch_assoc()){
    $data[] = [
        "index" => intval($row['option_selected']),
        "total" => intval($row['total'])
    ];
}

echo json_encode($data);


