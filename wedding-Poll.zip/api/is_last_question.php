<?php
header('Content-Type: application/json');
include("../config/db.php");

$code = $_GET['code'];

$event = $conn->query("
SELECT id, current_question_id 
FROM events 
WHERE unique_code='$code'
")->fetch_assoc();

$event_id = $event['id'];
$current_q = $event['current_question_id'];

// get ordered list
$res = $conn->query("
SELECT question_id 
FROM event_questions 
WHERE event_id=$event_id 
ORDER BY question_order ASC
");

$list = [];
while($row = $res->fetch_assoc()){
    $list[] = $row['question_id'];
}

// check position
$index = array_search($current_q, $list);

$is_last = ($index === count($list) - 1);

echo json_encode([
    "is_last" => $is_last ? 1 : 0
]);