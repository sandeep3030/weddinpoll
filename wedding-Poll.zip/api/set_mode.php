<?php
header('Content-Type: application/json');

$data = json_decode(file_get_contents("php://input"), true);

$mode = $data['mode'] ?? 'polling';

file_put_contents("../mode.txt", $mode);

echo json_encode(["status"=>"saved"]);