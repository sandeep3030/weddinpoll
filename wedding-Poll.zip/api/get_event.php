<?php
header('Content-Type: application/json');
include("../config/db.php");

$code = $_GET['code'] ?? '';

$res = $conn->query("SELECT name, cover_image FROM events WHERE unique_code='$code'");

if (!$res || $res->num_rows == 0) {
    echo json_encode([]);
    exit;
}

echo json_encode($res->fetch_assoc());