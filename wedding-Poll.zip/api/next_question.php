<?php
header('Content-Type: application/json');
include("../config/db.php");

$code = $_POST['code'];

$event = $conn->query("SELECT * FROM events WHERE unique_code='$code'")->fetch_assoc();
$event_id = $event['id'];

// get all questions
$q = $conn->query("
SELECT q.id FROM questions q
JOIN event_questions eq ON q.id = eq.question_id
WHERE eq.event_id = $event_id
ORDER BY eq.question_order ASC
");

$list = [];
while($r = $q->fetch_assoc()){
    $list[] = $r['id'];
}

// find next
$current = $event['current_question_id'];
$index = array_search($current, $list);

$next = $list[($index + 1) % count($list)];

// set time
$time = time();

$conn->query("
UPDATE events 
SET current_question_id=$next,
    question_start_time=$time
WHERE id=$event_id
");

echo json_encode(["status"=>"ok"]);