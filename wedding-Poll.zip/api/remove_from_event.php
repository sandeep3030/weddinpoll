<?php
header('Content-Type: application/json');
include("../config/db.php");

$data = json_decode(file_get_contents("php://input"), true);

$code = $data['code'];
$qid = $data['question_id'];

$event = $conn->query("SELECT id FROM events WHERE unique_code='$code'")->fetch_assoc();

if(!$event){
    echo json_encode(["status"=>"invalid"]);
    exit;
}

$event_id = $event['id'];

$conn->query("
DELETE FROM event_questions 
WHERE event_id=$event_id AND question_id=$qid
");

echo json_encode(["status"=>"removed"]);