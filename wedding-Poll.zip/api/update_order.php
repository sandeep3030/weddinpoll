<?php
header('Content-Type: application/json');
include("../config/db.php");

$data = json_decode(file_get_contents("php://input"), true);

$order = $data['order']; // array of question IDs
$code = $data['code'];

$event = $conn->query("SELECT id FROM events WHERE unique_code='$code'")->fetch_assoc();
$event_id = $event['id'];

$pos = 1;

foreach($order as $qid){
    $conn->query("
    UPDATE event_questions 
    SET question_order=$pos 
    WHERE event_id=$event_id AND question_id=$qid
    ");
    $pos++;
}

echo json_encode(["status"=>"updated"]);