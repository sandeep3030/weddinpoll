<?php
header('Content-Type: application/json');
include("../config/db.php");

$code = $_POST['code'];

// get event
$event = $conn->query("
SELECT id FROM events WHERE unique_code='$code'
")->fetch_assoc();

$event_id = $event['id'];

// 🗑 delete votes
$conn->query("DELETE FROM votes WHERE event_id=$event_id");

// get first question
$q = $conn->query("
SELECT question_id 
FROM event_questions 
WHERE event_id=$event_id 
ORDER BY question_order ASC 
LIMIT 1
")->fetch_assoc();

$first_q = $q['question_id'];

// reset event
$time = time();

$conn->query("
UPDATE events 
SET current_question_id=$first_q,
    question_start_time=$time
WHERE id=$event_id
");

echo json_encode(["status"=>"restarted"]);