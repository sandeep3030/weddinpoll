<?php
header('Content-Type: application/json');
include("../config/db.php");

$code = $_GET['code'];

$event = $conn->query("SELECT id FROM events WHERE unique_code='$code'")->fetch_assoc();
$event_id = $event['id'];

$q = "
SELECT q.id, q.question_text, eq.question_order
FROM questions q
JOIN event_questions eq ON q.id = eq.question_id
WHERE eq.event_id = $event_id
ORDER BY eq.question_order ASC
";

$res = $conn->query($q);

$data = [];
while($row = $res->fetch_assoc()){
    $data[] = $row;
}

echo json_encode($data);