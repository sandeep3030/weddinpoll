<?php
header('Content-Type: application/json');
include("../config/db.php");

$data = json_decode(file_get_contents("php://input"), true);

$code = $data['code'];
$optionIndex = intval($data['option']); // ✅ FIXED

// get event
$event = $conn->query("
SELECT id, current_question_id 
FROM events 
WHERE unique_code='$code'
")->fetch_assoc();

$event_id = $event['id'];
$question_id = $event['current_question_id'];

// insert vote
$conn->query("
INSERT INTO votes (event_id, question_id, option_selected)
VALUES ($event_id, $question_id, $optionIndex)
");

echo json_encode(["status"=>"ok"]);