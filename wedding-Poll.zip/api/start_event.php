<?php
header('Content-Type: application/json');
include("../config/db.php");

$code = $_POST['code'];

// get event
$event = $conn->query("
SELECT id FROM events WHERE unique_code='$code'
")->fetch_assoc();

if(!$event){
    echo json_encode(["error"=>"Event not found"]);
    exit;
}

$event_id = $event['id'];

// get first question
$q = $conn->query("
SELECT question_id 
FROM event_questions 
WHERE event_id=$event_id 
ORDER BY question_order ASC 
LIMIT 1
")->fetch_assoc();

if(!$q){
    echo json_encode(["error"=>"No questions in event"]);
    exit;
}

$first_q = $q['question_id'];

$time = time();

// ✅ CRITICAL FIX
$conn->query("
UPDATE events 
SET current_question_id=$first_q,
    question_start_time=$time,
    reveal_state=0
WHERE id=$event_id
");

echo json_encode(["status"=>"started"]);