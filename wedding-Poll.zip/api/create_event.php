<?php
include("../config/db.php");

$name = $_POST['name'];
$date = $_POST['date'];

// generate unique code
$code = strtoupper(substr(md5(time()), 0, 6));

$stmt = $conn->prepare("INSERT INTO events (name, event_date, unique_code) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $name, $date, $code);
$stmt->execute();

echo json_encode([
    "status" => "success",
    "code" => $code
]);