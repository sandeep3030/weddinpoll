<?php
include("../config/db.php");

$code = $_POST['code'];
$state = $_POST['state'];

$conn->query("
UPDATE events 
SET reveal_state=$state 
WHERE unique_code='$code'
");

echo json_encode(["ok"=>1]);