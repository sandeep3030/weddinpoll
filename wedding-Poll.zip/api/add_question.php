<?php
include("../config/db.php");

$data = json_decode(file_get_contents("php://input"), true);

$code = $data['event_code'];
$question = $data['question'];
$options = json_encode($data['options']);

// get event id
$event = $conn->query("SELECT id FROM events WHERE unique_code='$code'")->fetch_assoc();
$event_id = $event['id'];

// insert question
$conn->query("INSERT INTO questions (question_text, options) VALUES ('$question', '$options')");
$qid = $conn->insert_id;

// link to event
$conn->query("INSERT INTO event_questions (event_id, question_id) VALUES ($event_id, $qid)");

echo json_encode(["message" => "Question Added"]);