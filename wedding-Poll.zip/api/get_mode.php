<?php
header('Content-Type: application/json');
include("../config/db.php");

// simple file-based config (no DB needed)
$mode = file_exists("../mode.txt") ? trim(file_get_contents("../mode.txt")) : "polling";

echo json_encode(["mode"=>$mode]);