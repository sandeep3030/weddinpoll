<?php
header('Content-Type: application/json');
include("../config/db.php");

$code = $_POST['code'];
$mode = $_POST['mode']; // 0 auto, 1 manual

$conn->query("
UPDATE events 
SET control_mode=$mode 
WHERE unique_code='$code'
");

echo json_encode(["status"=>"ok"]);