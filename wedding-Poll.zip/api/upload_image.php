<?php
header('Content-Type: application/json');
include("../config/db.php");

$code = $_POST['code'] ?? '';

if (!$code || !isset($_FILES['image'])) {
    echo json_encode(["status"=>"error"]);
    exit;
}

// get event
$event = $conn->query("SELECT id FROM events WHERE unique_code='$code'")->fetch_assoc();

if (!$event) {
    echo json_encode(["status"=>"invalid event"]);
    exit;
}

// file upload
$file = $_FILES['image'];

$ext = pathinfo($file['name'], PATHINFO_EXTENSION);
$filename = "event_" . time() . "." . $ext;

$path = "../assets/images/" . $filename;

if (move_uploaded_file($file['tmp_name'], $path)) {

    // save path in DB
    $dbPath = "assets/images/" . $filename;

    $conn->query("UPDATE events SET cover_image='$dbPath' WHERE unique_code='$code'");

    echo json_encode([
        "status"=>"success",
        "path"=>$dbPath
    ]);
} else {
    echo json_encode(["status"=>"upload failed"]);
}