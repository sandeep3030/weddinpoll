<?php
header('Content-Type: application/json');
include("../config/db.php");

$code = $_POST['code'];
$mode = $_POST['mode']; // 1 = start, 0 = pause

$conn->query("
UPDATE events 
SET is_active=$mode 
WHERE unique_code='$code'
");

echo json_encode(["status"=>"ok"]);