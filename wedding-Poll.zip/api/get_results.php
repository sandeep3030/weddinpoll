<?php
header('Content-Type: application/json');
include("../config/db.php");

$code = $_GET['code'];

$event = $conn->query("SELECT id, current_question_id FROM events WHERE unique_code='$code'")->fetch_assoc();

$event_id = $event['id'];
$qid = $event['current_question_id'];

$res = $conn->query("
SELECT option_selected, COUNT(*) as total
FROM votes
WHERE event_id=$event_id AND question_id=$qid
GROUP BY option_selected
");

$data = [];

while($row = $res->fetch_assoc()){
    $data[] = [
        "index" => intval($row['option_selected']),
        "total" => intval($row['total'])
    ];
}

echo json_encode($data);