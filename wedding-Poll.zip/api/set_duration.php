<?php
header('Content-Type: application/json');
include("../config/db.php");

$code = $_POST['code'];
$duration = $_POST['duration'];

$conn->query("
UPDATE events 
SET question_duration=$duration 
WHERE unique_code='$code'
");

echo json_encode(["status"=>"ok"]);