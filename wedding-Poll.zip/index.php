<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Wedding Live Poll</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;600&display=swap" rel="stylesheet">

<style>
body {
    margin:0;
    font-family:'Poppins',sans-serif;
    color:white;
}

/* 🖼️ HERO BANNER */
.hero {
    position:relative;
    height:60vh;
    background: linear-gradient(135deg,#ff4da6,#ff9966);
    display:flex;
    align-items:center;
    justify-content:center;
    overflow:hidden;
}

.hero img {
    position:absolute;
    width:100%;
    height:100%;
    object-fit:cover;
    filter:brightness(0.6);
}

.overlay {
    position:relative;
    z-index:2;
    text-align:center;
}

.overlay h1 {
    font-size:40px;
}

.overlay h2 {
    font-weight:300;
}

/* 🎨 SECTION */
.container {
    padding:30px;
    text-align:center;
    background: linear-gradient(135deg,#ff4da6,#ff9966);
}

/* 🎯 BUTTONS */
.btn {
    display:inline-block;
    padding:15px 25px;
    margin:10px;
    border-radius:12px;
    background:white;
    color:#ff4da6;
    font-weight:600;
    text-decoration:none;
    box-shadow:0 5px 15px rgba(0,0,0,0.2);
    transition:0.3s;
}

.btn:hover {
    transform:translateY(-3px);
}
</style>
</head>

<body>

<!-- 🖼️ HERO -->
<div class="hero">
    <img id="cover" src="" style="display:none;">
    <div class="overlay">
        <h1>💍 Wedding Live Poll</h1>
        <h2 id="couple">Welcome to celebration</h2>
    </div>
</div>

<!-- 🎯 ACTIONS -->
<div class="container">

<p>Make your wedding fun & interactive 🎉</p>

<a id="joinBtn" href="guest/join.html" class="btn">📱 Join Event</a>
<a id="dashBtn" href="host/dashboard.html" class="btn">⚙ Host Dashboard</a>

</div>

<script>
const code = new URLSearchParams(window.location.search).get("code");

if(code){
    fetch(`api/get_event.php?code=${code}`)
    .then(res=>res.json())
    .then(data=>{

        if(data.name){
            document.getElementById("couple").innerText = "💖 " + data.name;
        }

        if(data.cover_image){
            let img = document.getElementById("cover");
            img.src = data.cover_image;
            img.style.display = "block";
        }

        // update links
        document.getElementById("joinBtn").href = "guest/join.html?code="+code;
        document.getElementById("dashBtn").href = "host/dashboard.html?code="+code;
    });
}
</script>

</body>
</html>