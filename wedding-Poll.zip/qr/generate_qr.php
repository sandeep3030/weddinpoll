<?php

$code = $_GET['code'];

// using Google QR API
$url = "http://localhost/wedding-poll/guest/join.html?code=" . $code;

header("Location: https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=" . urlencode($url));